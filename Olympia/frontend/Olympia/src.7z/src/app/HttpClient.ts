import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { user, score, athlet, medal } from './datatype';

type athletname = string;
type countryname = string;

@Injectable({ providedIn: 'root' })
export class RSHttpClient
{
    private _url: string = "http://localhost:80/backend.php";

    constructor(private httpClient: HttpClient)
    {
    }

    private post(parameters: {})
    {
        let header = new HttpHeaders();

        header = header.append('Content-Type', 'application/json').append('Accept', 'application/json');

        return this.httpClient.post<any>(this._url, parameters, { headers: header } );
    }

    public login(credentials: user)
    {
        const parameters = {
            endpoint: 'authentication_token',
            requiresToken: false,
            payload: credentials
        }

        return this.post(parameters);
    }

    public register(credentials: user)
    {
    }

    public addScore(score: score)
    {
    }

    public addAthlet(athletName: string, sportType: string, score: string, medal: medal)
    {
        
        const parameter = {
            method: 'setAthlet',
            args: { name: athletName, sportType, score, medal }
        }

        this.post(parameter);
    }

    public getScores(name?: countryname): Array<any>
    {
        let ret = new Array<score>();


        let parameter = {
            method: 'getScore',
            args: name == null ? {} : { name }
        }

        this.post(parameter);
        return ret;
    }
}
