import { Component, ElementRef, EventEmitter, Output, ViewChild } from '@angular/core';
import { user } from '../datatype';
import { RSHttpClient } from '../HttpClient';

@Component({
    selector: 'login-view',
    templateUrl: './loginView.html',
    styleUrls: ['./loginView.scss']
})
export class LoginView {    
    public username = '';
    public password = '';    


    @ViewChild('username')
    public usernameInput!: ElementRef<HTMLInputElement>;

    @ViewChild('password')
    public passwordInput!: ElementRef<HTMLInputElement>;

    @Output()
    public loggedIn: EventEmitter<boolean> = new EventEmitter<boolean>();

    constructor(private rsHttpClient: RSHttpClient)
    {
    }

    public onLoginButtonClicked()
    {
        this.username = this.usernameInput?.nativeElement.value as string;
        this.password = this.passwordInput?.nativeElement.value as string;

        if (this.username.length == 0)
        {
            alert('Der Benutzername darf nicht leer sein.');
            return;
        }

        if (this.password.length == 0)
        {
            alert('Das Passwort darf nicht leer sein.');
            return;
        }
        this.rsHttpClient.login(new user(this.username, this.password));
        this.loggedIn.emit(true);
    }
}
