import { Component, Input, OnInit } from '@angular/core';
import { athlet, medal } from '../datatype';
import { RSHttpClient } from '../HttpClient';



// Sportart, Athlet, Punktzahl Medaille
@Component({
    selector: 'admin-view',
    templateUrl: './adminView.html',
    styleUrls: ['./adminView.scss']
})
export class AdminView implements OnInit {


    public sporttype: string = '';
    public athlet: string = '';
    public score = '';
    public medal: medal = medal.None;

    constructor(private rsHttpClient: RSHttpClient)
    {

    }

    public ngOnInit(): void
    {
        
    }

    public onSubmit()
    {
        this.rsHttpClient.addAthlet(this.athlet, this.sporttype, this.score, this.medal);
    }
    
}