import { Component, OnInit } from '@angular/core';
import { athlet, medal, score } from '../datatype';
import { RSHttpClient } from '../HttpClient';

@Component({
    selector: 'country-view',
    templateUrl: './countryView.html',
    styleUrls: ['./countryView.scss']
})
export class CountryView implements OnInit {

    public selectedCountry: string = '';
    public scores: Array<any> = new Array<any>();
    public searchCountry: string = '';

    public get countrySelected()
    {
        return this.selectedCountry != '';
    }

    constructor(private rsHttpClient: RSHttpClient)
    {
    }

    public ngOnInit(): void
    {
        this.scores = this.rsHttpClient.getScores();

        this.scores.push({country: 'Deutschland', gold: '5', silver: '3', bronce: '9'},
        {country: 'Brasilien', gold: '5', silver: '3', bronce: '9'},
        {country: 'Portugal', gold: '5', silver: '3', bronce: '9'})
    }

    public onCountryClicked(e: any)
    {
        const countryName: string = e.target.innerText;
        this.selectedCountry = countryName;

        this.scores = this.rsHttpClient.getScores(this.selectedCountry);
    }

    public onBackClicked()
    {
        this.selectedCountry = '';
        this.scores = [{ country: 'Deutschland', gold: '5', silver: '3', bronce: '9'},
        {country: 'Brasilien', gold: '5', silver: '3', bronce: '9'},
        {country: 'Portugal', gold: '5', silver: '3', bronce: '9'}]
    }

    public search(value: Array<string>)
    {
        console.log('search', value);

        if (value.length < 1)
        {
            return;
        }

        this.searchCountry = value[0];
    }
}
