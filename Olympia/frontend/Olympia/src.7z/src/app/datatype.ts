export enum medal {
    'None',
    'Gold',
    'Silver',
    'Bronze'
}

export class user
{
    constructor(_name: string, _password: string)
    {
        this.name = _name;
        this.password = _password;
    }

    public name: string;
    public password: string;
}

export class athlet
{
    constructor(_country: string, _name: string)
    {
        this.country = _country;
        this.name = _name;
    }

    public country: string;
    public name: string;
}

export class score
{
    constructor(_medal: medal, _athletName: string, _sportType: string, _score: string)
    {
        this.medal = _medal;
        this.athletName = _athletName;
        this.sportType = _sportType;
        this.score = _score;
    }

    public medal: medal;
    public athletName: string;
    public sportType: string;
    public score: string; // wegen 1:15 und 9,62s
}