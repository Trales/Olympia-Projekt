import { Component, Input, OnInit } from '@angular/core';

export class ImageObject {
    public name = '';
    public src = '';

    constructor(_name: string, _src: string)
    {
        this.name = _name;
        this.src = _src;
    }
}

@Component({
    selector: 'content-view',
    templateUrl: './contentView.html',
    styleUrls: ['./contentView.scss']
})
export class ContentView implements OnInit {
    
    private _searchValues: Array<string> = new Array<string>();
    public selectedSportType: string = '';
    

    public get sportTypeSelected()
    {
        return this.selectedSportType != '';
    }

    @Input()
    public data: Array<{name: string, src: string}> = new Array();
    
    @Input()
    public set searchValues(value: Array<string>)
    {
        if (value.length > 3)
        {
            alert('searchValues zu klein');
        }
        const searchAthlet = value[0];
        const searchCountry = value[1];
        const searchScore = value[2];

        this._searchValues = value;
    }

    public get searchValues()
    {
        return this._searchValues;
    }

    constructor()
    {
        
    }

    public ngOnInit(): void
    {
        
    }

    public onSportTypeClicked(sportType: string)
    {
        this.selectedSportType = sportType;
    }
    
    public onBackClicked()
    {
        this.selectedSportType = '';
    }
}
