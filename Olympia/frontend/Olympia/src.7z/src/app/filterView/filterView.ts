import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
    selector: 'filter-view',
    templateUrl: './filterView.html',
    styleUrls: ['./filterView.scss']
})
export class FilterView implements OnInit {

    @Input()
    public filterInputs: Array<string> = new Array<string>();

    @Output()
    public searchClicked = new EventEmitter<Array<string>>();

    public inputValues: Array<string> = new Array<string>();
    
    constructor()
    {

    }
    
    
    ngOnInit(): void
    {
        
    }

    public onSearchClicked(e: any)
    {
        let result = new Array<string>();
        const inputElements = document.getElementsByClassName('filterInput') as any;

        for (let i = 0; i < inputElements.length; i++)
        {
            const element = inputElements[i] as any;
            result.push(element.value)
        }

        this.searchClicked.emit(result)
    }
}
