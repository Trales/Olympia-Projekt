import { Component, ViewChild } from '@angular/core';
import { ContentView, ImageObject } from './contentView/contentView';
import { CountryView } from './countryView/countryView';
import { RSHttpClient } from './HttpClient';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent {
    public title = 'Olympia';

    public activeTab: number = 0;
    public loggedIn: boolean = false;
    public showLoginView: boolean = false;
    public searchValues = new Array<string>();
    public filterInputs: Array<string> = new Array<string>();

    @ViewChild(CountryView)
    public countryView?: CountryView = undefined;

    @ViewChild(ContentView)
    public contentView?: ContentView = undefined;

    public contentViewData: Array<ImageObject> = [new ImageObject('100m - Sprint', '../assets/Leichtathletik.png'),
                                                  new ImageObject('Fechten', '../assets/fechten.webp'),
                                                  new ImageObject('Schwimmen', '../assets/schwimmen.jpg'),
                                                  new ImageObject('Sprungreiten', '../assets/sprungreiten.jpg'),
                                                  new ImageObject('Weitsprung', '../assets/weitsprung.jpg')];

    constructor() 
    {
    }

    public onShowLoginViewClicked()
    {
        this.showLoginView = true;
    }

    public onNavbarChanged(tab: number = 0)
    {
        if (tab == 0)
        {
            this.filterInputs = [];
        }
        else if (tab == 1)
        {
            this.filterInputs =['Land']
        }
        this.activeTab = tab;
    }

    public onLoggedIn(e: boolean)
    {
        this.loggedIn = e;
    }

    public onSearch(searchValues: Array<string>)
    {
        this.searchValues = searchValues;

        this.countryView?.search(searchValues);
    }
}
